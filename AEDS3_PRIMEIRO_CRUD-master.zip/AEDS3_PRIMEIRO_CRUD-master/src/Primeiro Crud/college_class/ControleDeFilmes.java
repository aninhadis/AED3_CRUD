package college_class;
import java.io.*;
import java.util.Scanner;
import java.util.*;
import java.text.SimpleDateFormat;
import aed3.*;
import aed3.ArquivoIndexado;

public class ControleDeFilmes {
    
    private static Scanner console = new Scanner(System.in);
    private static ArquivoIndexado<Filme> arqFilmes;

    public static void main(String[] args) {

        try {
           arqFilmes = new ArquivoIndexado<>(Filme.class, "filmes.db", "filmes1.idx", "filmes2.idx");
           
            // menu
            int opcao;
            do {
               System.out.println("\n\nCONTROLE DE FILMES");
               System.out.println("----------------------\n");
               System.out.println("1 - Listar");
               System.out.println("2 - Incluir");
               System.out.println("3 - Alterar");
               System.out.println("4 - Excluir");
               System.out.println("5 - Buscar por código");
               System.out.println("6 - Buscar por título de filme");
               System.out.println("9 - Reorganizar arquivo");
               System.out.println("0 - Sair");
               System.out.print("\nOpcao: ");
               opcao = Integer.valueOf(console.nextLine());
               
               switch(opcao) {
                   case 1: listarFilmes(); break;
                   case 2: incluirFilme(); break;
                   case 3: alterarFilme(); break;
                   case 4: excluirFilme(); break;
                   case 5: buscarFilmeCodigo(); break;
                   case 6: buscarFilmeTitulo(); break;
                   case 9: reorganizar(); break;
                   case 0: break;
                   default: System.out.println("Opção inválida");
               }
               
           } while(opcao != 0);
       } catch(Exception e) {
           e.printStackTrace();
       }
       
   }
   
   // PROJETOS
   
   public static void listarFilmes() throws Exception {
       
       Object[] obj = arqFilmes.listar();
       
       System.out.println("\nLISTA DE FILMES");
       for(int i=0; i<obj.length; i++) {
           System.out.println((Filme)obj[i]);
       }
       pausa();
       
   }
   
    public static void incluirFilme() throws Exception {
       
        int    codigo;
        String titulo;
        String tituloOriginal;
        String paisOrigem;
        short  anoLancamento;
        short  duracaoMinutos;
        String diretor;
        String sinopse;
       
        System.out.println("\nINCLUSAO DE PROJETO");
        System.out.print("Título: ");
        titulo = console.nextLine();

        System.out.println("Título Original: ");
        tituloOriginal = console.nextLine();

        System.out.println("País de Origem: ");
        paisOrigem = console.nextLine();

        System.out.print("Ano da lancamento: ");
        anoLancamento = console.nextShort();
        console.nextLine();
        System.out.print("Duracao em Minutos: ");
        duracaoMinutos = console.nextShort();
        console.nextLine();
        System.out.print("Diretor: ");
        diretor = console.nextLine();

        System.out.print("Sinopse: ");
        sinopse = console.nextLine();
    

        System.out.print("\nConfirma inclusão? ");
        char confirma = console.nextLine().charAt(0);
        if(confirma=='s' || confirma=='S') {
            Filme obj = new Filme(-1,titulo, tituloOriginal, paisOrigem,anoLancamento, duracaoMinutos, diretor, sinopse);
            int cod = arqFilmes.incluir(obj);
            System.out.println("Filme incluído com código: " + cod);
        }

        pausa();
    }

   
   public static void alterarFilme() throws Exception {
       
       System.out.println("\nALTERACAO DE FILME");

       int codigo;
       System.out.print("Código: ");
       codigo = Integer.valueOf(console.nextLine());
       if(codigo <=0) 
           return;
       
       Filme obj;
       if( (obj = (Filme)arqFilmes.buscarCodigo(codigo))!=null ) {
            System.out.println(obj);
            
            String titulo;
            String tituloOriginal;
            String paisOrigem;
            short  anoLancamento;
            short  duracaoMinutos;
            String diretor;
            String sinopse;
           
            System.out.println("\nALTERACAO DE PROJETO");
            System.out.print("Novo Título: ");
            titulo = console.nextLine();
    
            System.out.println("Novo Título Original: ");
             tituloOriginal = console.nextLine();

             System.out.println("Novo País de Origem: ");
             paisOrigem = console.nextLine();

             System.out.print("Novo Ano da lancamento: ");
             anoLancamento = console.nextShort();
             console.nextLine();

             System.out.print("Novo Duracao em Minutos: ");
             duracaoMinutos = console.nextShort();
             console.nextLine();
             
             System.out.print("Novo Diretor: ");
             diretor = console.nextLine();

             System.out.print("Novo Sinopse: ");
             sinopse = console.nextLine();

            if(titulo.length()>0 || diretor.length() > 0 || anoLancamento > 0) {
                System.out.print("\nConfirma alteração? ");
                char confirma = console.nextLine().charAt(0);
                if(confirma=='s' || confirma=='S') {

                obj.titulo  = (titulo.length()>0 ? titulo : obj.titulo);
                obj.diretor = (diretor.length()>0 ? diretor : obj.diretor);
                obj.anoLancamento   = (anoLancamento>=0 ? anoLancamento:obj.anoLancamento);

                if( arqFilmes.alterar(obj) ) 
                        System.out.println("Filme alterado.");
                    else
                        System.out.println("Filme não pode ser alterado.");
                }
            }
       }
       else
           System.out.println("ERROR: MOVIE NOT FOUND/FILME NAO ENCONTRADO");
       pausa();
       
   }
  
   
   public static void excluirFilme() throws Exception {
       
       System.out.println("\nEXCLUSÃO DE FILME");

       int codigo;
       System.out.print("Código: ");
       codigo = Integer.valueOf(console.nextLine());

       if(codigo <=0) 
           return;
       
       Filme obj;
       if( (obj = (Filme)arqFilmes.buscarCodigo(codigo))!=null ) {
            System.out.println(obj);
            
            System.out.print("\nConfirma exclusão? ");
            char confirma = console.nextLine().charAt(0);
            if(confirma=='s' || confirma=='S') {
                if( arqFilmes.excluir(codigo) ) {
                    System.out.println("Movie deleted from database/Filme excluído.");
                }
            }
       }
       else
           System.out.println("Error Class not found/Filme não encontrado");
       pausa();  
   }
   
   
   public static void buscarFilmeCodigo() throws Exception {
       
       System.out.println("\nBUSCA DE FILME POR CÓDIGO");
       
       int codigo;
       System.out.print("Código: ");
       codigo = Integer.valueOf(console.nextLine());
       if(codigo <=0) 
           return; 
       
       Filme obj;
       if( (obj = (Filme)arqFilmes.buscarCodigo(codigo))!=null )
           System.out.println(obj);
       else
           System.out.println("Error Class not found/Filme não encontrado");
       pausa();
   }

   public static void buscarFilmeTitulo() throws Exception {
       
       System.out.println("\nBUSCA DE FILME POR Título");
       
       String titulo;
       System.out.print("Título: ");
       titulo = console.nextLine();
       if(titulo.compareTo("")==0) 
           return;
       
       Filme obj;
       if( (obj = (Filme)arqFilmes.buscarString(titulo))!=null )
           System.out.println(obj);
       else
           System.out.println("Filme não encontrado");
       pausa();
   }

   
    public static void reorganizar() throws Exception {

        System.out.println("\nREORGANIZAÇÃO");
        arqFilmes.reorganizar();
        System.out.println("\nArquivo reorganizado");
        pausa();
    
    }
   
    public static void pausa() throws Exception {
        System.out.println("\nPressione ENTER para continuar ...");
        console.nextLine();
    }
}
