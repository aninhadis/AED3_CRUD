package college_class;
import aed3.Registro;
import java.io.*;

public class Filme implements Registro {
    protected int    codigo;
    protected String titulo;
    protected String tituloOriginal;
    protected String paisOrigem;
    protected short  anoLancamento;
    protected short  duracaoMinutos;
    protected String diretor;
    protected String sinopse;

    
    public Filme(int c, String t, String tOriginal, String pOrigem, short aLancamento, short dMinutos,
                 String d, String s) {
        codigo = c;
        titulo = t;
        tituloOriginal = tOriginal;
        paisOrigem = pOrigem;
        anoLancamento = aLancamento;
        duracaoMinutos = dMinutos;
        diretor = d;
        sinopse = s;
    }

    public Filme() {
        titulo = "";
        tituloOriginal = "";
        paisOrigem = "";
        anoLancamento = 0;
        duracaoMinutos = 0;
        diretor = "";
        sinopse = "";        
    }
    
    public String getString() {
        return titulo;
    }
    
    public String toString() {
        return "\nCódigo: " + codigo +
               "\nTítulo: " + titulo +
               "\nTítulo Original: " + tituloOriginal +
               "\nPaís de Origem: " + paisOrigem +
               "\nAno de Lançamento:" + anoLancamento +
               "\n"+
               "\nDuração em Minutos: " + duracaoMinutos +
               "\nDiretor: " + diretor +
               "\nSinopse: " + sinopse;
    }
    
    public byte[] getByteArray() throws IOException {
        ByteArrayOutputStream dados = new ByteArrayOutputStream();
        DataOutputStream saida = new DataOutputStream(dados);
        saida.writeInt(codigo);
        saida.writeUTF(titulo);
        saida.writeUTF(tituloOriginal);
        saida.writeUTF(paisOrigem);
        saida.writeShort(anoLancamento);
        saida.writeShort(duracaoMinutos);
        saida.writeUTF(diretor);
        saida.writeUTF(sinopse);
        return dados.toByteArray();        
    }
    
    public void setByteArray(byte[] b) throws IOException {
        ByteArrayInputStream dados = new ByteArrayInputStream(b);
        DataInputStream entrada = new DataInputStream(dados);
        codigo = entrada.readInt();
        titulo = entrada.readUTF();
        tituloOriginal = entrada.readUTF();
        paisOrigem = entrada.readUTF();
        anoLancamento = entrada.readShort();
        duracaoMinutos = entrada.readShort();
        diretor = entrada.readUTF();
        sinopse = entrada.readUTF();
    }

    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
    
    public int compareTo( Object b ) {
        return codigo - ((Filme)b).codigo;
    }
    public void setCodigo(int c) {
            codigo = c;
    }
        
    public int getCodigo() {
            return codigo;
    }
}
