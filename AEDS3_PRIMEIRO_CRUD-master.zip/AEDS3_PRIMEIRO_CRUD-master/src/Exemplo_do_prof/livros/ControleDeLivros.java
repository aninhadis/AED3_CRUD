package livros;
import java.io.*;
import java.util.Scanner;
import java.util.*;
import java.text.SimpleDateFormat;
import aed3.*;
import aed3.ArquivoIndexado;

public class ControleDeLivros {
    
    private static Scanner console = new Scanner(System.in);
    private static ArquivoIndexado<Livro> arqLivros;

   public static void main(String[] args) {

       try {
           arqLivros = new ArquivoIndexado<>(Livro.class, "livros.db", "livros1.idx", "livros2.idx");
           
           // menu
           int opcao;
           do {
               System.out.println("\n\nCONTROLE DE LIVROS");
               System.out.println("----------------------\n");
               System.out.println("1 - Listar");
               System.out.println("2 - Incluir");
               System.out.println("3 - Alterar");
               System.out.println("4 - Excluir");
               System.out.println("5 - Buscar por código");
               System.out.println("6 - Buscar por título");
               System.out.println("9 - Reorganizar arquivo");
               System.out.println("0 - Sair");
               System.out.print("\nOpcao: ");
               opcao = Integer.valueOf(console.nextLine());
               
               switch(opcao) {
                   case 1: listarLivros(); break;
                   case 2: incluirLivro(); break;
                   case 3: alterarLivro(); break;
                   case 4: excluirLivro(); break;
                   case 5: buscarLivroCodigo(); break;
                   case 6: buscarLivroTitulo(); break;
                   case 9: reorganizar(); break;
                   case 0: break;
                   default: System.out.println("Opção inválida");
               }
               
           } while(opcao!=0);
       } catch(Exception e) {
           e.printStackTrace();
       }
       
   }
   
   // PROJETOS
   
   public static void listarLivros() throws Exception {
       
       Object[] obj = arqLivros.listar();
       
       System.out.println("\nLISTA DE LIVROS");
       for(int i=0; i<obj.length; i++) {
           System.out.println((Livro)obj[i]);
       }
       pausa();
       
   }
   
   public static void incluirLivro() throws Exception {
       
       String titulo;
       String autor;
       float  preco;
       
       System.out.println("\nINCLUSAO DE PROJETO");
       System.out.print("Título: ");
       titulo = console.nextLine();
       System.out.print("Autor: ");
       autor = console.nextLine();
       System.out.print("Preço: ");
       preco = Float.parseFloat(console.nextLine());
       
       System.out.print("\nConfirma inclusão? ");
       char confirma = console.nextLine().charAt(0);
       if(confirma=='s' || confirma=='S') {
           Livro obj = new Livro(-1, titulo, autor, preco);
           int cod = arqLivros.incluir(obj);
           System.out.println("Livro incluído com código: "+cod);
       }
       pausa();
   }

   
   public static void alterarLivro() throws Exception {
       
       System.out.println("\nALTERACAO DE LIVRO");

       int codigo;
       System.out.print("Código: ");
       codigo = Integer.valueOf(console.nextLine());
       if(codigo <=0) 
           return;
       
       Livro obj;
       if( (obj = (Livro)arqLivros.buscarCodigo(codigo))!=null ) {
            System.out.println(obj);
            
            String titulo;
            String autor;
            float  preco;
            
            System.out.print("\nNovo título: ");
            titulo = console.nextLine();
            System.out.print("Novo autor: ");
            autor = console.nextLine();
            System.out.print("Novo preço: ");
            String auxPreco = console.nextLine();
            if(auxPreco.compareTo("")==0)
                preco=-1f;
            else
                preco = Float.parseFloat(auxPreco);

            if(titulo.length()>0 || autor.length()>0 || preco>=0) {
                System.out.print("\nConfirma alteração? ");
                char confirma = console.nextLine().charAt(0);
                if(confirma=='s' || confirma=='S') {

                obj.titulo = (titulo.length()>0 ? titulo : obj.titulo);
                obj.autor = (autor.length()>0 ? autor : obj.autor);
                obj.preco = (preco>=0?preco:obj.preco);

                if( arqLivros.alterar(obj) ) 
                        System.out.println("Livro alterado.");
                    else
                        System.out.println("Livro não pode ser alterado.");
                }
            }
       }
       else
           System.out.println("Livro não encontrado");
       pausa();
       
   }
  
   
   public static void excluirLivro() throws Exception {
       
       System.out.println("\nEXCLUSÃO DE LIVRO");

       int codigo;
       System.out.print("Código: ");
       codigo = Integer.valueOf(console.nextLine());
       if(codigo <=0) 
           return;
       
       Livro obj;
       if( (obj = (Livro)arqLivros.buscarCodigo(codigo))!=null ) {
            System.out.println(obj);
            
            System.out.print("\nConfirma exclusão? ");
            char confirma = console.nextLine().charAt(0);
            if(confirma=='s' || confirma=='S') {
                if( arqLivros.excluir(codigo) ) {
                    System.out.println("Livro excluído.");
                }
            }
       }
       else
           System.out.println("Livro não encontrado");
       pausa();
       
   }
   
   
   public static void buscarLivroCodigo() throws Exception {
       
       System.out.println("\nBUSCA DE LIVRO POR CÓDIGO");
       
       int codigo;
       System.out.print("Código: ");
       codigo = Integer.valueOf(console.nextLine());
       if(codigo <=0) 
           return; 
       
       Livro obj;
       if( (obj = (Livro)arqLivros.buscarCodigo(codigo))!=null )
           System.out.println(obj);
       else
           System.out.println("Livro não encontrado");
       pausa();
   }

   public static void buscarLivroTitulo() throws Exception {
       
       System.out.println("\nBUSCA DE LIVRO POR TITULO");
       
       String titulo;
       System.out.print("Título: ");
       titulo = console.nextLine();
       if(titulo.compareTo("")==0) 
           return;
       
       Livro obj;
       if( (obj = (Livro)arqLivros.buscarString(titulo))!=null )
           System.out.println(obj);
       else
           System.out.println("Livro não encontrado");
       pausa();
   }

   
   public static void reorganizar() throws Exception {

        System.out.println("\nREORGANIZAÇÃO");
        arqLivros.reorganizar();
        System.out.println("\nArquivo reorganizado");
        pausa();
    
   }
   
    public static void pausa() throws Exception {
        System.out.println("\nPressione ENTER para continuar ...");
        console.nextLine();
    }
    
}
