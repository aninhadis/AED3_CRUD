package college_class;
import java.io.*;
import java.util.Scanner;
import java.util.*;
import java.text.SimpleDateFormat;
import aed3.*;
import aed3.ArquivoIndexado;

public class ControleDeCursos {
    
    private static Scanner console = new Scanner(System.in);
    private static ArquivoIndexado<Curso> arqCursos;

   public static void main(String[] args) {

       try {
           arqCursos = new ArquivoIndexado<>(Curso.class, "cursos.db", "cursos1.idx", "cursos2.idx");
           
           // menu
           int opcao;
           do {
               System.out.println("\n\nCONTROLE DE CURSOS");
               System.out.println("----------------------\n");
               System.out.println("1 - Listar");
               System.out.println("2 - Incluir");
               System.out.println("3 - Alterar");
               System.out.println("4 - Excluir");
               System.out.println("5 - Buscar por código");
               System.out.println("6 - Buscar por título");
               System.out.println("9 - Reorganizar arquivo");
               System.out.println("0 - Sair");
               System.out.print("\nOpcao: ");
               opcao = Integer.valueOf(console.nextLine());
               
               switch(opcao) {
                   case 1: listarCursos(); break;
                   case 2: incluirCurso(); break;
                   case 3: alterarCurso(); break;
                   case 4: excluirCurso(); break;
                   case 5: buscarCursoCodigo(); break;
                   case 6: buscarCursoTitulo(); break;
                   case 9: reorganizar(); break;
                   case 0: break;
                   default: System.out.println("Opção inválida");
               }
               
           } while(opcao!=0);
       } catch(Exception e) {
           e.printStackTrace();
       }
       
   }
   
   // PROJETOS
   
   public static void listarCursos() throws Exception {
       
       Object[] obj = arqCursos.listar();
       
       System.out.println("\nLISTA DE CursoS");
       for(int i=0; i<obj.length; i++) {
           System.out.println((Curso)obj[i]);
       }
       pausa();
       
   }
   
   public static void incluirCurso() throws Exception {
       
       String titulo;
       String tipo;
       String descricao;
       String professor;
       String categoria;
       float  preco;
       
       System.out.println("\nINCLUSAO DE PROJETO");
       System.out.print("Título: ");
       titulo = console.nextLine();
       System.out.println("Tipo de curso \n exemplo: \n 1:presencial  \n 2:virtual  \n3:hibrido");
       tipo = console.nextLine();
       System.out.println("Descricao sobre o curso:");
       descricao = console.nextLine();
       System.out.print("professor: ");
       professor = console.nextLine();
       System.out.println("categoria exemplos: \n 1:História \n2:Humanas \n3:Exatas \n4:Matemática");
       categoria= console.nextLine();
       System.out.print("Preço: ");
       preco = Float.parseFloat(console.nextLine());
       
       System.out.print("\nConfirma inclusão? ");
       char confirma = console.nextLine().charAt(0);
       if(confirma=='s' || confirma=='S') {
           Curso obj = new Curso(-1, titulo, tipo, descricao, professor, categoria, preco);
           int cod = arqCursos.incluir(obj);
           System.out.println("Curso incluído com código: "+cod);
       }
       pausa();
   }

   
   public static void alterarCurso() throws Exception {
       
       System.out.println("\nALTERACAO DE CURSO");

       int codigo;
       System.out.print("Código: ");
       codigo = Integer.valueOf(console.nextLine());
       if(codigo <=0) 
           return;
       
       Curso obj;
       if( (obj = (Curso)arqCursos.buscarCodigo(codigo))!=null ) {
            System.out.println(obj);
            
            String titulo;
            String tipo;
            String descricao;
            String professor;
            String categoria;
            float  preco;
            
            System.out.print("\nNovo título: ");
            titulo = console.nextLine();

            System.out.print("Novo tipo curso exemplo: \n 1:presencial  \n 2:virtual  \n3:hibrido");
            tipo = console.nextLine();

            System.out.print("Nova descrição");
            descricao= console.nextLine();

            System.out.print("Novo professor: ");
            professor = console.nextLine();

            System.out.print("Nova categoria exemplos: \n 1:História \n2:Humanas \n3:Exatas \n4:Matemática");
            categoria= console.nextLine();

            System.out.print("Novo preço: ");
            String auxPreco = console.nextLine();
            if(auxPreco.compareTo("")==0)
                preco=-1f;
            else
                preco = Float.parseFloat(auxPreco);

            if(titulo.length()>0 || professor.length()>0 || preco>=0) {
                System.out.print("\nConfirma alteração? ");
                char confirma = console.nextLine().charAt(0);
                if(confirma=='s' || confirma=='S') {

                obj.titulo = (titulo.length()>0 ? titulo : obj.titulo);
                obj.professor = (professor.length()>0 ? professor : obj.professor);
                obj.preco = (preco>=0?preco:obj.preco);

                if( arqCursos.alterar(obj) ) 
                        System.out.println("Curso alterado.");
                    else
                        System.out.println("Curso não pode ser alterado.");
                }
            }
       }
       else
           System.out.println("ERROR: CURSO NOT FOUND/CURSO NAO ENCONTRADO");
       pausa();
       
   }
  
   
   public static void excluirCurso() throws Exception {
       
       System.out.println("\nEXCLUSÃO DE CURSO");

       int codigo;
       System.out.print("Código: ");
       codigo = Integer.valueOf(console.nextLine());
       if(codigo <=0) 
           return;
       
       Curso obj;
       if( (obj = (Curso)arqCursos.buscarCodigo(codigo))!=null ) {
            System.out.println(obj);
            
            System.out.print("\nConfirma exclusão? ");
            char confirma = console.nextLine().charAt(0);
            if(confirma=='s' || confirma=='S') {
                if( arqCursos.excluir(codigo) ) {
                    System.out.println("College class deleted/Curso excluído.");
                }
            }
       }
       else
           System.out.println("Error Class not found/Curso não encontrado");
       pausa();
       
   }
   
   
   public static void buscarCursoCodigo() throws Exception {
       
       System.out.println("\nBUSCA DE CURSO POR CÓDIGO");
       
       int codigo;
       System.out.print("Código: ");
       codigo = Integer.valueOf(console.nextLine());
       if(codigo <=0) 
           return; 
       
       Curso obj;
       if( (obj = (Curso)arqCursos.buscarCodigo(codigo))!=null )
           System.out.println(obj);
       else
           System.out.println("Error Class not found/Curso não encontrado");
       pausa();
   }

   public static void buscarCursoTitulo() throws Exception {
       
       System.out.println("\nBUSCA DE CURSO POR Título");
       
       String titulo;
       System.out.print("Título: ");
       titulo = console.nextLine();
       if(titulo.compareTo("")==0) 
           return;
       
       Curso obj;
       if( (obj = (Curso)arqCursos.buscarString(titulo))!=null )
           System.out.println(obj);
       else
           System.out.println("Curso não encontrado");
       pausa();
   }

   
   public static void reorganizar() throws Exception {

        System.out.println("\nREORGANIZAÇÃO");
        arqCursos.reorganizar();
        System.out.println("\nArquivo reorganizado");
        pausa();
    
   }
   
    public static void pausa() throws Exception {
        System.out.println("\nPressione ENTER para continuar ...");
        console.nextLine();
    }
    
}
