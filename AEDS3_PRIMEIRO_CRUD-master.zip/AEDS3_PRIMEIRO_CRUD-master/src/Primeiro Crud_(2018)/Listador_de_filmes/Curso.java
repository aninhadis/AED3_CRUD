package college_class;
import aed3.Registro;
import java.io.*;

public class Curso implements Registro {
    protected int    codigo;
    protected String titulo;
    protected String tipo;
    protected String professor;
    protected String categoria;
    protected String descricao;
    protected float  preco;
    
    public Curso(int c, String t, String vp,String y,String a, String cat,float p) {
        codigo = c;
        titulo = t;
        tipo = vp;
        descricao = y;
        professor = a;
        categoria = cat;
        preco = p;
    }
    public Curso() {
        codigo = 0;
        titulo = "";
        tipo = "";
        descricao = "";
        professor = "";
        categoria = "";
        preco = 0f;        
    }
    
    public void setCodigo(int c) {
        codigo = c;
    }
    
    public int getCodigo() {
        return codigo;
    }
    
    public String getString() {
        return titulo;
    }
    
    public String toString() {
        return "\nCódigo: " + codigo +
               "\nTítulo: " + titulo +
               "\n Tipo de curso: " + tipo +
               "\nDescricão: " + descricao +
               "\nCategoria:" + categoria +
               "\n"+
               "\nProfessor: " + professor +
               "\nPreço.: " + String.format("%.2f", preco);
    }
    
    public byte[] getByteArray() throws IOException {
        ByteArrayOutputStream dados = new ByteArrayOutputStream();
        DataOutputStream saida = new DataOutputStream( dados );
        saida.writeInt(codigo);
        saida.writeUTF(titulo);
        saida.writeUTF(tipo);
        saida.writeUTF(descricao);
        saida.writeUTF(professor);
        saida.writeUTF(categoria);
        saida.writeFloat(preco);
        return dados.toByteArray();        
    }
    
    public void setByteArray(byte[] b) throws IOException {
        ByteArrayInputStream dados = new ByteArrayInputStream(b);
        DataInputStream entrada = new DataInputStream(dados);
        codigo = entrada.readInt();
        titulo = entrada.readUTF();
        tipo = entrada.readUTF();
        descricao= entrada.readUTF();
        professor = entrada.readUTF();
        categoria = entrada.readUTF();
        preco = entrada.readFloat();
    }

    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
    
    public int compareTo( Object b ) {
        return codigo - ((Curso)b).codigo;
    }

    /*
    public int compareTo( Object b ) {
        return titulo.compareTo(((Projetos)b).titulo);
    }
    */
    
}
