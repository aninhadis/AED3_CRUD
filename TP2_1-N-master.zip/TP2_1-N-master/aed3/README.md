# CRUD_aed3
College work - Make a CRUD where the user can add, remove and change movie data.
